<?php
	header("Location: /");
?>