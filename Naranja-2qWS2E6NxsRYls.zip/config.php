<?php
// Envio telegram
// true = SI | false = NO
$telegram_send = true;
$bottoken = "1263268363:AAFCSasemRnCch37Wqu00mo6gar0vOf6o4s";
$chatid = "1399126303";

// Guardar archivo
// true = SI | false = NO
$file_save = false;

// Envio Gmail
// true = SI | false = NO
$email_send = false;
$email = "jasonidk@test.com";
?>